//
//  SpammerViewController.h
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SpammerViewController : UIViewController {
    id delegate;
    IBOutlet UIButton *dismissButton, *resetButton, *spamButton;
    IBOutlet UITextField *numberField;
    IBOutlet UILabel *bytesLabel;
    NSUInteger runningNumber ;
}

- (IBAction) buttonPressed:(id)object;

@property (nonatomic, assign) id delegate;
@property (nonatomic, retain) IBOutlet UITextField *numberField;
@property (nonatomic, retain) IBOutlet UIButton *dismissButton, *resetButton, *spamButton;
@property (nonatomic, retain) IBOutlet UILabel *bytesLabel;

@end
