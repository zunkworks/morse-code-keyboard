//
//  SpammerViewController.m
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SpammerViewController.h"
#import "TerminalViewController.h"

@implementation SpammerViewController

@synthesize delegate;
@synthesize dismissButton, resetButton, spamButton;
@synthesize numberField;
@synthesize bytesLabel;

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
    [theTextField setText:[NSString stringWithFormat:@"%u", [[theTextField text] intValue]]]; // Checks for validity
    [theTextField resignFirstResponder];
    return YES;
}


- (IBAction) buttonPressed:(id)object {
    if(object == dismissButton) {
        if([delegate respondsToSelector:@selector(spammerShouldClose)]) {
            // our delegate (SpammerViewController) will handle closing this modal view
            [delegate spammerShouldClose];
        }
    } else if (object == resetButton) {
        runningNumber = 0;
        bytesLabel.text = @"0";
    } else if (object == spamButton) {
        // Hand generated data to SpammerViewController
        for(NSUInteger i = 0; i < [[numberField text] intValue]; i++)
          [delegate stringFromSpammer:[NSString stringWithFormat:@"%07u", runningNumber++]];
        // NOTE: the byte counter counts the terminating null character as well, because it's sent over the air too!
        bytesLabel.text = [NSString stringWithFormat:@"%u", runningNumber*8];
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        runningNumber = 0;
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
