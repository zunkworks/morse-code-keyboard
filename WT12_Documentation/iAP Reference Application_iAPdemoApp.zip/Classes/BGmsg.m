//
//  BGmsg.m
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import "BGmsg.h"


@implementation BGmsg

// Create getters and setters for all of the data fields
@synthesize bytes;
@synthesize size;
@synthesize timestamp;
@synthesize incoming;

// Our data constructor
- (id) initWithData:(const unsigned char*)ptr len:(UInt32)len isIncoming:(BOOL)isIncoming {
    self = [super init];
    if(!self) return nil;
    
	size = len;
	bytes = malloc(size);
	memcpy(bytes, ptr, size);
	timestamp = [NSDate new]; // Get current time
	incoming = isIncoming;
	return self;
}

// Our string constructor
- (id) initWithString:(NSString *)str isIncoming:(BOOL)isIncoming {
    self = [super init];
    if(!self) return nil;
    
	size = [str lengthOfBytesUsingEncoding:NSUTF8StringEncoding] + 1;
	bytes = malloc(size);
	[str getCString:(char*)bytes maxLength:size encoding:NSUTF8StringEncoding];
	timestamp = [[NSDate alloc] initWithTimeIntervalSinceNow:0]; // Get current time
	incoming = isIncoming;
	return self;
}

- (NSString*) toString {
    if(bytes[size - 1] == 0x00) 
        return [NSString stringWithCString:(char*)bytes encoding:NSUTF8StringEncoding];
    else {
        char *tmp = malloc(size + 1);
        memcpy(tmp, bytes, size);
        tmp[size] = '\0';
        return [NSString stringWithCString:tmp encoding:NSUTF8StringEncoding];
    }
}

- (void) dealloc {
	free(bytes);
    [timestamp release];
	[super dealloc];
}

@end
