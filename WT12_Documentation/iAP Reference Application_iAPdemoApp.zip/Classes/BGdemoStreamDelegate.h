//
//  BGdemoStreamDelegate.h
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ExternalAccessory/ExternalAccessory.h>

@class BGdemoAppDelegate;

@interface BGdemoStreamDelegate : NSObject <NSStreamDelegate> {
    @private
    BGdemoAppDelegate *appDelegate;
    EASession *session;
    NSMutableData *outbuf;
}

- (id)initWithSession:(EASession*)s appDelegate:(BGdemoAppDelegate*)aD;
- (void)sendData:(uint8_t*)data length:(NSUInteger)len;

// A class that implements the NSStreamDelegate protocol has to handle this message
- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent;

@property (nonatomic, assign) BGdemoAppDelegate *appDelegate;
@property (nonatomic, retain) EASession *session;
@property (nonatomic, retain
           ) NSMutableData *outbuf;

@end
