//
//  HelloWorldAppDelegate.m
//  HelloWorld
//
//  Created by Jori Rintahaka on 12/5/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "TerminalViewController.h"
#import "HelloWorldAppDelegate.h"

@implementation HelloWorldAppDelegate

@synthesize viewCtrl;
@synthesize window;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
	TerminalViewController *ctrl = [[TerminalViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
	self.viewCtrl = ctrl;
	[ctrl release];
	[window addSubview:[viewCtrl view]];
    [window makeKeyAndVisible];
}


- (void)dealloc {
	[viewCtrl release];
    [window release];
    [super dealloc];
}


@end
