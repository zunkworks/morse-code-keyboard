//
//  HelloWorldAppDelegate.h
//  HelloWorld
//
//  Created by Jori Rintahaka on 12/5/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TerminalViewController;

@interface HelloWorldAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	TerminalViewController *viewCtrl;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) TerminalViewController *viewCtrl;

@end

