//
//  TerminalViewController.h
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BGdemoAppDelegate;
@class SpammerViewController;

@interface TerminalViewController : UIViewController {
    @private
	UITextField *textField;
	UITextView *textView;
	UISwitch *displayHexSwitch, *inputHexSwitch;
    UIButton *spammerButton;
	BGdemoAppDelegate *appDelegate;
    SpammerViewController *spamCtrl;
    
	int textViewLineCount;
	NSMutableArray *msgBuf;
	NSDate *startTime;
}

- (void) receivedData:(uint8_t*)data length:(NSUInteger)len;
- (void) spammerShouldClose;
- (void) stringFromSpammer:(NSString*)str;

@property (nonatomic, retain) IBOutlet UITextField *textField;
@property (nonatomic, retain) IBOutlet UITextView *textView;
@property (nonatomic, retain) IBOutlet UISwitch *displayHexSwitch, *inputHexSwitch;
@property (nonatomic, retain) IBOutlet UIButton *spammerButton;
@property (nonatomic, assign) BGdemoAppDelegate *appDelegate;
@property (nonatomic, assign) SpammerViewController *spamCtrl;
- (IBAction)buttonPressed:(id)sender;

@end
