//
//  BGdemoAppDelegate.h
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ExternalAccessory/ExternalAccessory.h>

@class TerminalViewController;
@class ConnectionViewController;
@class BGdemoStreamDelegate;

@interface BGdemoAppDelegate : NSObject <UIApplicationDelegate, EAAccessoryDelegate> {
    @private
    UIWindow *window;
	TerminalViewController *viewCtrl;
	ConnectionViewController *connCtrl;
    BGdemoStreamDelegate *streamDelegate;
    @public
}

- (void)receivedData:(unsigned char *)data length:(NSUInteger)len;
- (BOOL)checkForiWRAP;
- (void)registerAccessoryNotifications;
- (void)sendData:(uint8_t*) data length:(NSUInteger) len;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) TerminalViewController *viewCtrl;
@property (nonatomic, retain) ConnectionViewController *connCtrl;
@property (nonatomic, retain) BGdemoStreamDelegate *streamDelegate;

@end

