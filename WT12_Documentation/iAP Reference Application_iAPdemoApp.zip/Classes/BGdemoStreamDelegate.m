//
//  BGdemoStreamDelegate.m
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import "BGdemoStreamDelegate.h"
#import "BGdemoAppDelegate.h"

#define DATA_CHUNK_SIZE     (64)

@implementation BGdemoStreamDelegate

@synthesize session;
@synthesize appDelegate;
@synthesize outbuf;

- (id)initWithSession:(EASession*)sess appDelegate:(BGdemoAppDelegate*)aD {
    self = [super init];
    if(!self) return nil;
    
    session = sess;
    appDelegate = aD;
    outbuf = [NSMutableData new];
    return self;
}

// This is called when we get an incoming data event. Notify the appDelegate that we have data to print.
- (void)handleIncoming:(NSInputStream*)stream {
    while ([stream hasBytesAvailable]) {
        unsigned char buf[DATA_CHUNK_SIZE];
        NSUInteger len;
        len = [stream read:buf maxLength:DATA_CHUNK_SIZE];
        if(len>0) [appDelegate receivedData:buf length:len];
    }
}

- (void)handleSpace:(NSOutputStream*)stream {
    if ([session.outputStream streamStatus] != NSStreamStatusOpen &&
        [session.outputStream streamStatus] != NSStreamStatusWriting) {
        NSLog(@"handleSpace: streamStatus invalid!");
        return;
    }
    NSInteger done = [session.outputStream write:[outbuf bytes] maxLength:[outbuf length]];
    if(done > 0) [outbuf replaceBytesInRange:NSMakeRange(0, done) withBytes:nil length:0]; // Remove sent bytes from buffer    
}

- (void)sendData:(uint8_t*)data length:(NSUInteger)len {
    [outbuf appendBytes:data length:len];
    if([session.outputStream hasSpaceAvailable]) {
        [self handleSpace:session.outputStream];
    }
}

// This is where we receive notifications of incoming data and space to push outgoing data
- (void)stream:(NSStream *)stream handleEvent:(NSStreamEvent)event {
    if(event & NSStreamEventErrorOccurred) {
        // TODO: handle errors
        NSLog(@"stream error");
        return;
    }
    
    if(stream == session.inputStream && event & NSStreamEventHasBytesAvailable)
        [self handleIncoming:(NSInputStream*) stream];
    
    if(stream == session.outputStream && event & NSStreamEventHasSpaceAvailable)
        [self handleSpace:(NSOutputStream*) stream];
}

- (void)dealloc {
    [outbuf release];
    [super dealloc];
}


@end
