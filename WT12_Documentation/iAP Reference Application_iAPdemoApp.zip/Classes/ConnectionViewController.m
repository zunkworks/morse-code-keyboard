//
//  ConnectionViewController.m
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import "ConnectionViewController.h"
#import "BGdemoAppDelegate.h"
#import <ExternalAccessory/ExternalAccessory.h>

@implementation ConnectionViewController

@synthesize halpButton;
@synthesize appDelegate;
@synthesize activityIndicator;
@synthesize connectingLabel, infoLabel;

- (void) accessoryConnected:(EAAccessory *)acc {
    NSLog(@"%s", __FUNCTION__);
    connectingLabel.text = @"Connected!";
    infoLabel.text = [NSString stringWithFormat:@"Manufacturer: %@\nName: %@\nModel: %@", 
                      [acc manufacturer], [acc name], [acc modelNumber]];
    [activityIndicator stopAnimating];
    [activityIndicator setHidden:YES];
}

- (void) accessoryDisconnected {
    NSLog(@"%s", __FUNCTION__);
    connectingLabel.text = @"Disconnected, waiting for connection...";
    infoLabel.text = @"";
    [activityIndicator startAnimating];
    [activityIndicator setHidden:NO];
    [appDelegate.window bringSubviewToFront:self.view];
}

- (IBAction) buttonPressed: (id)sender {
	if(sender == halpButton) {
		NSLog(@"HALP!");
		[appDelegate.window bringSubviewToFront:[appDelegate.viewCtrl view]];
	}
}
/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    [activityIndicator startAnimating];
    // Tell the app delegate we're ready to get accessory notifications
    [appDelegate registerAccessoryNotifications];

}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
    [halpButton release];
    [connectingLabel release];
    [infoLabel release];
    [activityIndicator release];
    [super dealloc];
}


@end
