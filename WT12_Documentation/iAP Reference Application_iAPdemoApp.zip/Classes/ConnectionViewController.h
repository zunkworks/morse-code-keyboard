//
//  ConnectionViewController.h
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
@class EAAccessory;
@class BGdemoAppDelegate;

@interface ConnectionViewController : UIViewController {
    @private
	IBOutlet UIButton *halpButton;
    IBOutlet UIActivityIndicatorView *activityIndicator;
    IBOutlet UILabel *connectingLabel, *infoLabel;
	BGdemoAppDelegate *appDelegate;
}

- (void) accessoryConnected:(EAAccessory*)acc;
- (void) accessoryDisconnected;

@property (nonatomic, assign) BGdemoAppDelegate *appDelegate;
@property (nonatomic, retain) IBOutlet UIButton *halpButton;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (nonatomic, retain) IBOutlet UILabel *connectingLabel, *infoLabel;
- (IBAction)buttonPressed:(id)sender;

@end
