//
//  TerminalViewController.m
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import "BGmsg.h"
#import "TerminalViewController.h"
#import "BGdemoAppDelegate.h"
#import "SpammerViewController.h"

@implementation TerminalViewController

// Synthesize getters and setters for the GUI elements
@synthesize textField;
@synthesize textView;
@synthesize displayHexSwitch, inputHexSwitch;
@synthesize spammerButton;
@synthesize appDelegate;
@synthesize spamCtrl;

- (IBAction) buttonPressed:(id)sender {
    // Open a modal view, set this view controller as its delegate
    if(sender == spammerButton) {
        spamCtrl = [[SpammerViewController alloc] initWithNibName:@"SpammerView" bundle:[NSBundle mainBundle]]; 
        spamCtrl.delegate = self;
        [spamCtrl setModalPresentationStyle:UIModalPresentationFormSheet];
        [self presentModalViewController:spamCtrl animated:YES];
    }
}

// Spammer told us it's ready to close
- (void) spammerShouldClose {
    [self dismissModalViewControllerAnimated:YES];
    [spamCtrl release];
}

// Print another line of I/O
- (void)appendToTextField:(BGmsg*)msg {
	CGPoint scrollPoint = textView.contentOffset; // Get content offset before we add more
	textViewLineCount += 1;
	
	// Add timestamp and direction
	textView.text = [textView.text stringByAppendingString: 
					  [NSString stringWithFormat:@"\n%.2lf %s", [msg.timestamp timeIntervalSinceDate:startTime], msg.incoming ? " << " : " >> "]];
	
	if(!displayHexSwitch.on) {
        @try {
            textView.text = [textView.text stringByAppendingString: [msg toString]];
        }
        @catch (NSException *e) {
            textView.text = [textView.text stringByAppendingString:@"Can't print message"];
            NSLog(@"Got exception");
        }
        @finally {
        }
	}
    else {
		NSMutableString *str = [NSMutableString new];
		for(UInt32 i = 0; i < msg.size; i++)
			[str appendFormat:@"%02x ", msg.bytes[i]];
		textView.text = [textView.text stringByAppendingString:str];
		[str release];
	}
	
	if(textViewLineCount > textView.frame.size.height / ([[textView font] pointSize] + 3)) { // Scroll if necessary
		scrollPoint.y += [[textView font] pointSize] + 3;
		[textView setContentOffset:scrollPoint animated:YES];
	}
}

// textFieldShouldReturn is called when the user presses return on the textfield.
// We are the textfield's delegate, so we can override this function here.
- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
    if (theTextField == textField) {
        [textField resignFirstResponder]; // Hide keyboard
    }
	
	if([textField.text compare:@""] == NSOrderedSame) return YES; // No input
	
	BGmsg *msg;
	if(!inputHexSwitch.on) {
		msg = [[BGmsg alloc] initWithString:textField.text isIncoming:NO];
		[msgBuf addObject:msg]; // Add message to our buffer in raw form
	} else {
		// Check we got full bytes
		if([textField.text length] % 2 == 0) {
			unsigned char *hexbuf;
			UInt32 len = ([textField.text length] / 2);
			hexbuf = malloc(len);
			
			for(UInt32 i = 0; i < len; i++) {
				NSUInteger tmp;
				NSScanner *s = [NSScanner scannerWithString:[textField.text substringWithRange:NSMakeRange(i*2, 2)]];
				if(![s scanHexInt:&tmp]) {
					//NSLog(@"Invalid character between chars %u-%u", i*2, i*2 + 1);
					//[msg release];
					return YES;
				}
				hexbuf[i] = tmp & 0x000000ff;
				//NSLog(@"Appending %02x", hexbuf[i]);
			}
			
			msg = [[BGmsg alloc] initWithData:hexbuf len:len isIncoming:NO];
			free(hexbuf);
		} else {
			// Invalid input
			return YES;
		}
		[msgBuf addObject:msg];
	}
    [appDelegate sendData:msg.bytes length:msg.size];
	[msg release];

	[self appendToTextField:[msgBuf objectAtIndex:[msgBuf count] - 1]];
		
    return YES;
}

- (void) receivedData:(uint8_t*)data length:(NSUInteger)len {
    BGmsg *msg = [[BGmsg alloc] initWithData:data len:len isIncoming:YES];
    [msgBuf addObject:msg];
    [self appendToTextField:msg];
    [msg release];
}

// Our spammer modal view gave us some data to send
- (void) stringFromSpammer:(NSString *)str {
    BGmsg *msg = [[BGmsg alloc] initWithString:str isIncoming:NO];
    [msgBuf addObject:msg];
    [appDelegate sendData:msg.bytes length:msg.size];
    [self appendToTextField:msg];
    [msg release];
}

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	textView.text = @"Hello! This is the Bluegiga iAP example application!";
	textViewLineCount = 3;
	textView.font = [UIFont fontWithName:@"Helvetica" size:12];
	msgBuf = [[NSMutableArray alloc] init];
	startTime = [[NSDate alloc] init];
	textField.keyboardType = UIKeyboardTypeASCIICapable;
	textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}


- (void)dealloc {
	[textField release];
	[textView release];
	[msgBuf release];
	[startTime release];
    [super dealloc];
}


@end
