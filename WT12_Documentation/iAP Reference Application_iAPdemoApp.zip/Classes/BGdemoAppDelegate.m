//
//  BGdemoAppDelegate.m
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//

#import "TerminalViewController.h"
#import "BGdemoAppDelegate.h"
#import "ConnectionViewController.h"
#import <ExternalAccessory/ExternalAccessory.h>
#import "BGdemoStreamDelegate.h"

@implementation BGdemoAppDelegate

@synthesize viewCtrl;
@synthesize connCtrl;
@synthesize window;
@synthesize streamDelegate;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    // Override point for customization after application launch
	TerminalViewController *ctrl = [[TerminalViewController alloc] initWithNibName:@"ControllerView" bundle:[NSBundle mainBundle]];
	ctrl.appDelegate = self;
	viewCtrl = ctrl;
	
	ConnectionViewController *cctrl = [[ConnectionViewController alloc] initWithNibName:@"ConnectionView" bundle:[NSBundle mainBundle]];
	cctrl.appDelegate = self;
	connCtrl = cctrl;
    
    NSLog(@"%@", [[NSBundle mainBundle] bundleIdentifier]);
    
    self.streamDelegate = nil;
	
	[window addSubview:[viewCtrl view]];
	[window addSubview:[connCtrl view]];
    [window makeKeyAndVisible];
}

- (BOOL)checkForiWRAP {
    // Get list of connected accessories
    NSArray *accList = [[EAAccessoryManager sharedAccessoryManager] connectedAccessories];
    
    EAAccessory *iWRAP = nil;
    EASession *session = nil;
    
    // Iterate through accessory list, search for BGiAP protocol
    for(EAAccessory *acc in accList) {
        NSLog(@"acc found");
        if([[acc protocolStrings] containsObject:@"com.bluegiga.iwrap"]) {
            NSLog(@"Found iWRAP accessory!");
            iWRAP = acc;
            break;
        }
    }
    
    if(!iWRAP) return NO;
    
    session = [[EASession alloc] initWithAccessory:iWRAP forProtocol:@"com.bluegiga.iwrap"];
    
    if(!session) {
        NSLog(@"Couldn't create session!");
        return NO;
    }
    
    // Initialize our stream delegate
    streamDelegate = [[BGdemoStreamDelegate alloc] initWithSession:session appDelegate:self];
    
    // Set our BGdemoStreamDelegate instance to receive stream events
    [session.outputStream setDelegate:streamDelegate];
    [session.inputStream setDelegate:streamDelegate]; 
    
    // Schedule stream I/O in the current runloop
    [session.inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    [session.outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    
    // Open fire
    [session.inputStream open];
    [session.outputStream open];
    [session release];
    return YES;
    
}

// We receive this notification when a new accessory connects
- (void) accessoryConnected:(NSNotification*) notification {
    NSLog(@"%s", __FUNCTION__);
    
    // If we have a streamDelegate, then we're already connected, ignore the newly connected device
    if(streamDelegate) return;
    
    // Check that it was iWRAP that connected to us
    if([self checkForiWRAP]) {
        // Notify connection view controller that we're connected
        [connCtrl accessoryConnected:streamDelegate.session.accessory];
    }
}

// This is received for disconnected accessories
// FIXME: check that the disconnected accessory is the one that we are using!
- (void) accessoryDisconnected:(NSNotification*) notification {
    NSLog(@"%s", __FUNCTION__);

    if(streamDelegate && [[notification userInfo] objectForKey:EAAccessoryKey]) {
        [streamDelegate release];
        streamDelegate = nil;
        [connCtrl accessoryDisconnected];
    }
}

// Register notifications of connected and disconnected accessories and do initial check
- (void)registerAccessoryNotifications {
    [[EAAccessoryManager sharedAccessoryManager] registerForLocalNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accessoryConnected:) 
                                                 name:EAAccessoryDidConnectNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accessoryDisconnected:) 
                                                 name:EAAccessoryDidDisconnectNotification object:nil];
    // Do initial check, we won't receive a notification if it's already connected when the app starts
    if([self checkForiWRAP]) {
        // Notify connection view controller that we're connected
        [connCtrl accessoryConnected:streamDelegate.session.accessory];
    }
}

// streamDelegate gave us some data, hand it over to viewCtrl to print out
- (void)receivedData:(uint8_t *)data length:(NSUInteger)len {
    [viewCtrl receivedData:data length:len];
}

// Notify the streamDelegate that we want to send data
- (void)sendData:(uint8_t*) data length:(NSUInteger) len {
    if(streamDelegate)
        [streamDelegate sendData:data length:len];
}

- (void)dealloc {
	[viewCtrl release];
	[connCtrl release];
    [streamDelegate release];
    [window release];
    [super dealloc];
}


@end
