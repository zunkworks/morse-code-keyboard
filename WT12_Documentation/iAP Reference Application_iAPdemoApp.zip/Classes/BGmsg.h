//
//  BGmsg.h
//  BGdemoApp
//
//  Created by Jori Rintahaka on 5/3/11.
//  Copyright 2011 Bluegiga Technologies. All rights reserved.
//


// Helper class for storing sent and received data
@interface BGmsg : NSObject {
    @public
	unsigned char *bytes;
	UInt32 size;
	BOOL incoming;
	NSDate *timestamp;
}

- (id) initWithData:(const unsigned char*)ptr len:(UInt32)len isIncoming:(BOOL)isIncoming;
- (id) initWithString:(NSString *)str isIncoming:(BOOL)isIncoming;
- (NSString*) toString;

@property (nonatomic, readonly) BOOL incoming;
@property (nonatomic, readonly) unsigned char *bytes;
@property (nonatomic, readonly) UInt32 size;
@property (nonatomic, readonly) NSDate *timestamp;

@end
