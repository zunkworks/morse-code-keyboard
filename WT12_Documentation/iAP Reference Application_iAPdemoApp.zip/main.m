//
//  main.m
//  HelloWorld
//
//  Created by Jori Rintahaka on 12'/5/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sys/signal.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    signal(SIGPIPE, SIG_IGN); // Ignore broken pipe signals, handle write errors locally
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
